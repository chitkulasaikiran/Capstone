package com.capstone.service;

import com.capstone.entity.User;

public interface UserService {
    public  User addUser(User user);
}